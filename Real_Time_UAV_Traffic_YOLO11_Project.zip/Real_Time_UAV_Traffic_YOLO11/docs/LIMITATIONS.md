# Known limitations and responsible use

- Requires an external labeled dataset and trained weights for traffic-specific results.
- Small aerial targets, occlusion, motion blur, nighttime scenes, and domain shift can reduce accuracy.
- Camera/video frame counts are not unique object counts; no multi-object tracking or speed estimation is implemented.
- This code does not calculate vehicle speed, traffic density per road area, or violation events.
- The supplied validation results are modest, especially for bicycle and awning-tricycle categories.
- Respect local UAV flight rules, privacy, data permissions, and third-party dataset/model licensing.
- This is a research starter repository, not a safety-critical traffic-control product.
