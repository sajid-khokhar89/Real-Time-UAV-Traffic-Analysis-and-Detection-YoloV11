# Installation

1. Install Python 3.9+ (3.11 recommended).
2. Create a virtual environment: `python -m venv .venv`.
3. Activate it, then run `pip install -e ".[dev]"` from the repository root.
4. Check the CLI: `uav-traffic --help`.
5. If using an NVIDIA GPU, install a CUDA-compatible PyTorch build following the official PyTorch instructions. Check with `python -c "import torch; print(torch.cuda.is_available())"`.
6. Use `--device 0` for the first GPU or `--device cpu` otherwise.

No Docker is required. Video preview (`--show`) requires a desktop display; omit it on Kaggle/headless servers.
