# Commands

After `pip install -e .`:

```bash
uav-traffic train --data configs/data.yaml --model yolo11s.pt --epochs 100 --batch 16 --device 0
uav-traffic validate --weights runs/detect/train/weights/best.pt --data configs/data.yaml --device 0
uav-traffic predict --weights runs/detect/train/weights/best.pt --source samples/road.jpg --save --device 0
uav-traffic video --weights runs/detect/train/weights/best.pt --source samples/road.mp4 --output outputs/road.mp4 --csv outputs/road.csv --device 0
uav-traffic video --weights runs/detect/train/weights/best.pt --source 0 --show --max-frames 300
```

`video` CSV records detected objects **per frame**, not distinct vehicles or traffic flow. Frames with no detections produce no class rows. For object tracking and unique vehicle counts, a separate tracker and line-crossing logic must be added.

Kaggle: set the dataset YAML path to the Kaggle input dataset location, choose `--device 0`, and write outputs to `/kaggle/working` if desired.
