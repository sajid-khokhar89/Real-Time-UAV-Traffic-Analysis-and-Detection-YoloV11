# Dataset format

This example assumes the 10 traffic categories shown in `configs/data.yaml`, matching the user's validation output. It does **not** include or redistribute the dataset.

Expected structure:

```text
datasets/traffic/
  images/train/*.jpg
  images/val/*.jpg
  images/test/*.jpg
  labels/train/*.txt
  labels/val/*.txt
  labels/test/*.txt
```

Each YOLO label row is `class_id x_center y_center width height` with normalized coordinates in [0,1]. Class IDs must follow the YAML mapping exactly. Ensure splits do not leak near-duplicate video frames. If your data is VISDRONE or another UAV benchmark, check the original license and confirm category mapping before training.

Check paths: `python scripts/check_dataset.py --data configs/data.yaml`.

**Note:** YAML `path` is resolved by Ultralytics according to its own dataset rules; use an absolute dataset path if relative resolution is ambiguous in your environment.
