# Contributing

Open an issue with reproduction steps, expected/actual behavior, environment, and anonymized examples. Add tests for fixes. Avoid committing datasets, private videos, or model weights without redistribution rights.
