"""Basic dataset directory/label checks. Run from repository root."""
import argparse
from pathlib import Path
import yaml


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", default="configs/data.yaml")
    args = p.parse_args()
    config_path = Path(args.data).resolve()
    data = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    root = Path(data["path"])
    if not root.is_absolute():
        root = (config_path.parent / root).resolve()
    print("Dataset root:", root)
    for split in ("train", "val", "test"):
        if split not in data:
            continue
        images = root / data[split]
        files = [p for p in images.rglob("*") if p.suffix.lower() in {".jpg", ".jpeg", ".png"}] if images.exists() else []
        print(f"{split}: {len(files)} images; directory exists={images.exists()}")
    print("Class names:", data["names"])


if __name__ == "__main__":
    main()
