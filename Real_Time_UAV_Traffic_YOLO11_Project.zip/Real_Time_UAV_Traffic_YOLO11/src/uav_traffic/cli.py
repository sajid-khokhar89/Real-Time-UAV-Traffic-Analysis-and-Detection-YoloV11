"""Command-line entry point."""
import argparse


def build_parser():
    parser = argparse.ArgumentParser(description="UAV YOLO11 traffic analysis")
    sub = parser.add_subparsers(dest="command", required=True)
    tr = sub.add_parser("train", help="Train YOLO11")
    tr.add_argument("--data", default="configs/data.yaml")
    tr.add_argument("--model", default="yolo11s.pt")
    tr.add_argument("--epochs", type=int, default=100)
    tr.add_argument("--imgsz", type=int, default=640)
    tr.add_argument("--batch", type=int, default=16)
    tr.add_argument("--device", default="cpu")
    tr.add_argument("--seed", type=int, default=42)
    tr.add_argument("--project", default="runs/detect")
    tr.add_argument("--name", default="train")
    va = sub.add_parser("validate", help="Evaluate trained weights")
    va.add_argument("--weights", required=True)
    va.add_argument("--data", default="configs/data.yaml")
    va.add_argument("--imgsz", type=int, default=640)
    va.add_argument("--batch", type=int, default=16)
    va.add_argument("--device", default="cpu")
    pr = sub.add_parser("predict", help="Predict on an image/folder/video")
    pr.add_argument("--weights", required=True)
    pr.add_argument("--source", required=True)
    pr.add_argument("--conf", type=float, default=0.25)
    pr.add_argument("--iou", type=float, default=0.45)
    pr.add_argument("--imgsz", type=int, default=640)
    pr.add_argument("--device", default="cpu")
    pr.add_argument("--save", action="store_true")
    vi = sub.add_parser("video", help="Save annotated video and per-frame CSV")
    vi.add_argument("--weights", required=True)
    vi.add_argument("--source", required=True, help="Video path or camera index e.g. 0")
    vi.add_argument("--output", default="outputs/annotated.mp4")
    vi.add_argument("--csv", default="outputs/counts.csv")
    vi.add_argument("--conf", type=float, default=0.25)
    vi.add_argument("--iou", type=float, default=0.45)
    vi.add_argument("--imgsz", type=int, default=640)
    vi.add_argument("--device", default="cpu")
    vi.add_argument("--show", action="store_true")
    vi.add_argument("--max-frames", type=int, default=0)
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    if args.command == "train":
        from .train import train
        train(args.data, args.model, args.epochs, args.imgsz, args.batch, args.device,
              args.seed, args.project, args.name)
    elif args.command == "validate":
        from .evaluate import validate
        validate(args.weights, args.data, args.imgsz, args.batch, args.device)
    elif args.command == "predict":
        from .detect import predict
        for _ in predict(args.weights, args.source, args.conf, args.iou, args.imgsz, args.device, args.save):
            pass
    elif args.command == "video":
        from .video import run_video
        run_video(args.weights, args.source, args.output, args.csv, args.conf, args.iou,
                  args.imgsz, args.device, args.show, args.max_frames)
