"""Lazy model loader to avoid importing heavyweight packages in utility tests."""
from pathlib import Path


def load_model(weights: str):
    from ultralytics import YOLO
    if not Path(weights).exists() and not weights.startswith(("yolo11", "yolov")):
        raise FileNotFoundError(f"Weights not found: {weights}")
    return YOLO(weights)
