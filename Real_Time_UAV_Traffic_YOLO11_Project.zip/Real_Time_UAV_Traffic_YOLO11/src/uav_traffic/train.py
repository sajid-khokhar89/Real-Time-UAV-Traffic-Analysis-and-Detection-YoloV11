"""Model training."""
from pathlib import Path
from .model import load_model


def train(data: str, model: str, epochs: int, imgsz: int, batch: int, device: str, seed: int, project: str, name: str):
    if not Path(data).is_file():
        raise FileNotFoundError(f"Dataset YAML not found: {data}")
    net = load_model(model)
    return net.train(data=data, epochs=epochs, imgsz=imgsz, batch=batch, device=device,
                     seed=seed, project=project, name=name)
