"""Image, directory, or video prediction with Ultralytics."""
from .model import load_model


def predict(weights: str, source: str, conf: float, iou: float, imgsz: int, device: str, save: bool):
    return load_model(weights).predict(source=source, conf=conf, iou=iou, imgsz=imgsz,
                                       device=device, save=save, stream=True)
