"""Expected class order for the provided traffic dataset example."""
CLASSES = (
    "pedestrian", "people", "bicycle", "car", "van", "truck",
    "tricycle", "awning-tricycle", "bus", "motor",
)
