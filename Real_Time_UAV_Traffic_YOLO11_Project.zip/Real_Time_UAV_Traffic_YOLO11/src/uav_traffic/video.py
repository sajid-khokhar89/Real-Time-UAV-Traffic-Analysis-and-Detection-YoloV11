"""Read a video/camera, draw YOLO detections, and export per-frame counts."""
import csv
from pathlib import Path
from .analytics import count_detections
from .model import load_model


def run_video(weights: str, source: str, output: str, csv_path: str, conf: float, iou: float,
              imgsz: int, device: str, show: bool = False, max_frames: int = 0):
    import cv2
    capture_source = int(source) if source.isdecimal() else source
    cap = cv2.VideoCapture(capture_source)
    if not cap.isOpened():
        raise RuntimeError(f"Unable to open video source: {source}")
    fps = cap.get(cv2.CAP_PROP_FPS)
    if not fps or fps <= 0 or fps != fps:
        fps = 25.0
    model = load_model(weights)
    out_path, csv_file = Path(output), Path(csv_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    csv_file.parent.mkdir(parents=True, exist_ok=True)
    writer = None
    frame_index = 0
    try:
        with csv_file.open("w", newline="", encoding="utf-8") as f:
            csv_writer = csv.writer(f)
            csv_writer.writerow(["frame", "time_sec", "class", "count"])
            while True:
                ok, frame = cap.read()
                if not ok or (max_frames and frame_index >= max_frames):
                    break
                result = model.predict(frame, conf=conf, iou=iou, imgsz=imgsz,
                                       device=device, verbose=False)[0]
                annotated = result.plot()
                if writer is None:
                    height, width = annotated.shape[:2]
                    writer = cv2.VideoWriter(str(out_path), cv2.VideoWriter_fourcc(*"mp4v"),
                                             fps, (width, height))
                    if not writer.isOpened():
                        raise RuntimeError(f"Unable to create video: {out_path}")
                writer.write(annotated)
                class_ids = result.boxes.cls.cpu().tolist() if result.boxes is not None else []
                counts = count_detections(class_ids, result.names)
                for label, count in sorted(counts.items()):
                    csv_writer.writerow([frame_index, round(frame_index / fps, 3), label, count])
                if show:
                    cv2.imshow("UAV Traffic Detection", annotated)
                    if cv2.waitKey(1) & 0xFF == ord("q"):
                        break
                frame_index += 1
    finally:
        cap.release()
        if writer is not None:
            writer.release()
        if show:
            cv2.destroyAllWindows()
    print(f"Processed {frame_index} frames; video: {out_path}; counts: {csv_file}")
