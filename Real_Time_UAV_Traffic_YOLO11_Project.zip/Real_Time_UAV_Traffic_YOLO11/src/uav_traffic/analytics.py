"""Frame-level detection counts (not unique vehicle tracking)."""
from collections import Counter


def count_detections(class_ids, names):
    """Map predicted class indices to counts; accepts dict or list of names."""
    result = Counter()
    for class_id in class_ids:
        idx = int(class_id)
        label = names[idx] if isinstance(names, (list, tuple)) else names.get(idx, str(idx))
        result[label] += 1
    return dict(result)
