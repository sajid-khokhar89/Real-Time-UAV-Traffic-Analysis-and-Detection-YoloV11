"""Validation helper."""
from pathlib import Path
from .model import load_model


def validate(weights: str, data: str, imgsz: int, batch: int, device: str):
    if not Path(data).is_file():
        raise FileNotFoundError(f"Dataset YAML not found: {data}")
    metrics = load_model(weights).val(data=data, imgsz=imgsz, batch=batch, device=device)
    print(f"mAP50={metrics.box.map50:.4f}  mAP50-95={metrics.box.map:.4f}")
    return metrics
