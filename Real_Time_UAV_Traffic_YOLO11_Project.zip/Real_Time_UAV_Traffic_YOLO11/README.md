# Real-Time UAV Traffic Analysis and Detection with YOLO11

Modular Python project for training, validating, and running YOLO11 traffic detection on UAV images, videos, and camera streams. Supports optional annotated video output, per-frame class counts, and CSV summaries.

> **Important:** The repository includes source code and documentation, **not** trained weights or the original dataset. The performance figures below are supplied from an earlier validation log, not reproduced by this repository.

## Validation reference

| Metric | Value |
|---|---:|
| Images / instances | 548 / 38,759 |
| Precision / Recall | 0.550 / 0.428 |
| mAP50 / mAP50-95 | 0.441 / 0.267 |

## Quick start

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows: .venv\Scripts\activate
pip install -r requirements.txt
# Download/prepare the dataset yourself and edit configs/data.yaml
python -m uav_traffic train --data configs/data.yaml --model yolo11s.pt --epochs 100 --imgsz 640
python -m uav_traffic validate --weights runs/detect/train/weights/best.pt --data configs/data.yaml
python -m uav_traffic predict --weights runs/detect/train/weights/best.pt --source path/to/image.jpg --save
python -m uav_traffic video --weights runs/detect/train/weights/best.pt --source path/to/video.mp4 --output outputs/annotated.mp4 --csv outputs/counts.csv
```

If installing from a clone instead of `pip install -e .`, set `PYTHONPATH=src` before running `python -m uav_traffic`.

## Features

- YOLO11 training, validation, and inference via Ultralytics
- 10 traffic classes and configurable dataset paths
- Image/folder/video/camera inference
- Video annotations and per-frame object count CSV
- Modular, typed helpers; simple unit tests; configuration examples

## Project layout

```text
src/uav_traffic/   CLI, training, validation, detection, video analytics
configs/           Dataset YAML and example configuration
scripts/           Dataset structure check
samples/           (user-created) input imagery
weights/           (user-created) best.pt
outputs/           (generated) predictions and summaries
docs/              Setup, data, evaluation, limitations
 tests/             Unit tests
```

## Documentation

See [Setup](docs/SETUP.md), [Dataset](docs/DATASET.md), [Usage](docs/USAGE.md), [Evaluation](docs/EVALUATION.md), and [Limitations](docs/LIMITATIONS.md).

## License

MIT license applies to original repository code only. Dataset, model weights, and third-party packages retain their own licenses.
