# Changelog

## 0.1.0
- Initial modular training, validation, inference, video analytics, CLI, and documentation.
