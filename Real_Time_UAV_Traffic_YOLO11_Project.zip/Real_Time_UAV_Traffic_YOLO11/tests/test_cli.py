from uav_traffic.cli import build_parser


def test_train_defaults():
    args = build_parser().parse_args(["train"])
    assert args.model == "yolo11s.pt"
    assert args.epochs == 100


def test_video_source():
    args = build_parser().parse_args(["video", "--weights", "best.pt", "--source", "0"])
    assert args.source == "0"
