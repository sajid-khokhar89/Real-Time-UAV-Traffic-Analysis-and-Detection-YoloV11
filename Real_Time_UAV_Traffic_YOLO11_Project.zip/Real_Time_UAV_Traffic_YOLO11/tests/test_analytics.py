from uav_traffic.analytics import count_detections


def test_counts_with_dict_names():
    assert count_detections([0, 1, 1], {0: "car", 1: "bus"}) == {"car": 1, "bus": 2}


def test_empty_counts():
    assert count_detections([], ["car"]) == {}
